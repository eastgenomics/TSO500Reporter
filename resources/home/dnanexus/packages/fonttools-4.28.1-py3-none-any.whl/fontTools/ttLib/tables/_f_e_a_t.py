from .otBase import BaseTTXConverter


class table__f_e_a_t(BaseTTXConverter):
	pass
